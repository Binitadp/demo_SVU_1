import { createBrowserRouter, RouterProvider } from "react-router-dom";


import LandingPage from "./pages/Landing";
import NotFound from "./pages/404NotFound";
import Login from "./pages/auth/Login";
import DirectorPage from "./pages/director";
import HQOfficerPage from "./pages/hqofficer";
import MinisterPage from "./pages/minister";
import SupervisorPage from "./pages/supervisor";

const routes = createBrowserRouter([
  {
    path: "/",
    element: <LandingPage />,
  },
  {
    path: "/login",
    element: <Login />,
  },
  {
    path: "/director",
    element: <DirectorPage />,
  },
  {
    path: "/hqofficer",
    element: <HQOfficerPage />,
  },
  {
    path: "/minister",
    element: <MinisterPage />,
  },
  {
    path: "/supervisor",
    element: <SupervisorPage />,
  },
  {
    path: "*",
    element: <NotFound />,
  },
]);

const AppRouter = () => {
  return <RouterProvider router={routes} />;
};

export default AppRouter;
