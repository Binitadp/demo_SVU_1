
import React from "react";
import { Link } from "react-router-dom";

const LandingPage: React.FC = () => {
  return (
    <div className="flex min-h-svh items-center justify-center flex-col gap-4">
      <p className="text-lg opacity-80">
        Welcome to the Zoo Management System!
      </p>
      <Link to="/login" className="text-blue-600 underline text-base">Login</Link>
    </div>
  );
};
export default LandingPage;
