import React from "react";

const NotFound: React.FC = () => {
  return (
    <div className="flex min-h-svh items-center justify-center">
      <p className="text-lg opacity-80">Page Not Found!</p>
    </div>
  );
};

export default NotFound;
