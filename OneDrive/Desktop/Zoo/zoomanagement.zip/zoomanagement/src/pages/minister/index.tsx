import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Sidebar } from '../../components/Sidebar';
import { LayoutDashboard, DollarSign, BookOpen, FileText, BarChart3, Calendar, TrendingUp } from 'lucide-react';

const MinisterPage = () => {
  const navigate = useNavigate();
  const [currentView, setCurrentView] = useState('dashboard');

  const menuItems = [
    { icon: LayoutDashboard, label: 'Dashboard', view: 'dashboard' },
    { icon: DollarSign, label: 'Budget', view: 'budget' },
    { icon: BookOpen, label: 'Policies', view: 'policies' },
  ];

  const dropdownGroups = [
    {
      icon: FileText,
      label: 'Reports',
      items: [
        { icon: Calendar, label: 'Daily Report', view: 'daily-report' },
        { icon: BarChart3, label: 'Monthly Report', view: 'monthly-report' },
        { icon: TrendingUp, label: 'Annual Report', view: 'annual-report' },
      ],
    },
  ];

  const handleLogout = () => {
    navigate('/login');
  };

  const renderContent = () => {
    switch (currentView) {
      case 'dashboard':
        return (
          <div>
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Dashboard</h2>
            <p className="text-gray-600">Welcome to the Minister Dashboard. Oversee policy and governance.</p>
          </div>
        );
      case 'budget':
        return (
          <div>
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Budget</h2>
            <p className="text-gray-600">Manage budget allocations and financial planning.</p>
          </div>
        );
      case 'policies':
        return (
          <div>
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Policies</h2>
            <p className="text-gray-600">Review and update zoo policies and regulations.</p>
          </div>
        );
      case 'daily-report':
        return (
          <div>
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Daily Report</h2>
            <p className="text-gray-600">View daily operational reports.</p>
          </div>
        );
      case 'monthly-report':
        return (
          <div>
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Monthly Report</h2>
            <p className="text-gray-600">View monthly statistics and summaries.</p>
          </div>
        );
      case 'annual-report':
        return (
          <div>
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Annual Report</h2>
            <p className="text-gray-600">View annual performance metrics.</p>
          </div>
        );
      default:
        return (
          <div>
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Dashboard</h2>
            <p className="text-gray-600">Welcome, Minister!</p>
          </div>
        );
    }
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar
        title="Zoo Management"
        menuItems={menuItems}
        dropdownGroups={dropdownGroups}
        currentView={currentView}
        onViewChange={setCurrentView}
        user={{ name: 'Minister', label: 'Role' }}
        onLogoutClick={handleLogout}
      />
      <main className="flex-1 overflow-y-auto">
        <div className="p-8">
          {renderContent()}
        </div>
      </main>
    </div>
  );
};

export default MinisterPage;
