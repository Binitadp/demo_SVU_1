import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Sidebar } from '../../components/Sidebar';
import { LayoutDashboard, Dog, Users, FileText, BarChart3, Calendar, TrendingUp } from 'lucide-react';

const DirectorPage = () => {
  const navigate = useNavigate();
  const [currentView, setCurrentView] = useState('dashboard');

  const menuItems = [
    { icon: LayoutDashboard, label: 'Dashboard', view: 'dashboard' },
    { icon: Dog, label: 'Animals', view: 'animals' },
    { icon: Users, label: 'Staff', view: 'staff' },
  ];

  const dropdownGroups = [
    {
      icon: FileText,
      label: 'Reports',
      items: [
        { icon: Calendar, label: 'Daily Report', view: 'daily-report' },
        { icon: BarChart3, label: 'Monthly Report', view: 'monthly-report' },
        { icon: TrendingUp, label: 'Annual Report', view: 'annual-report' },
      ],
    },
  ];

  const handleLogout = () => {
    navigate('/login');
  };

  const renderContent = () => {
    switch (currentView) {
      case 'dashboard':
        return (
          <div>
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Dashboard</h2>
            <p className="text-gray-600">Welcome to the Director Dashboard. Overview of zoo operations.</p>
          </div>
        );
      case 'animals':
        return (
          <div>
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Animals</h2>
            <p className="text-gray-600">Manage animal inventory and health records.</p>
          </div>
        );
      case 'staff':
        return (
          <div>
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Staff Management</h2>
            <p className="text-gray-600">View and manage staff members.</p>
          </div>
        );
      case 'daily-report':
        return (
          <div>
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Daily Report</h2>
            <p className="text-gray-600">View daily operational reports.</p>
          </div>
        );
      case 'monthly-report':
        return (
          <div>
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Monthly Report</h2>
            <p className="text-gray-600">View monthly statistics and summaries.</p>
          </div>
        );
      case 'annual-report':
        return (
          <div>
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Annual Report</h2>
            <p className="text-gray-600">View annual performance metrics.</p>
          </div>
        );
      default:
        return (
          <div>
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Dashboard</h2>
            <p className="text-gray-600">Welcome, Director!</p>
          </div>
        );
    }
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar
        title="Zoo Management"
        menuItems={menuItems}
        dropdownGroups={dropdownGroups}
        currentView={currentView}
        onViewChange={setCurrentView}
        user={{ name: 'Director', label: 'Role' }}
        onLogoutClick={handleLogout}
      />
      <main className="flex-1 overflow-y-auto">
        <div className="p-8">
          {renderContent()}
        </div>
      </main>
    </div>
  );
};

export default DirectorPage;
