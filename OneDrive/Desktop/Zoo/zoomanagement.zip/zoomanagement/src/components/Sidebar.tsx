import {
  User,
  LogOut,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { useState } from 'react';

// Type definitions for the modular sidebar
export interface MenuItem {
  icon: React.ComponentType<React.SVGProps<SVGSVGElement>>;
  label: string;
  view: string;
  onClick?: () => void;
}

export interface DropdownGroup {
  icon: React.ComponentType<React.SVGProps<SVGSVGElement>>;
  label: string;
  items: MenuItem[];
}

export interface SidebarUser {
  name: string;
  label?: string;
}

export interface SidebarProps {
  // Branding
  title?: string;

  // Navigation
  menuItems: MenuItem[];
  dropdownGroups?: DropdownGroup[];
  currentView: string;
  onViewChange: (view: string) => void;

  // User section (optional)
  user?: SidebarUser;
  onProfileClick?: () => void;
  onLogoutClick?: () => void;
}

export function Sidebar({
  title = 'App',
  menuItems,
  dropdownGroups = [],
  currentView,
  onViewChange,
  user,
  onProfileClick,
  onLogoutClick
}: SidebarProps) {
  // Track which dropdown groups are open
  const [openDropdowns, setOpenDropdowns] = useState<Record<string, boolean>>({});

  const toggleDropdown = (label: string) => {
    setOpenDropdowns(prev => ({
      ...prev,
      [label]: !prev[label]
    }));
  };

  const handleMenuClick = (item: MenuItem) => {
    if (item.onClick) {
      item.onClick();
    } else {
      onViewChange(item.view);
    }
  };

  return (
    <aside className="w-64 bg-white border-r border-gray-200 flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-gray-200">
        <h1 className="text-gray-900 text-xl font-semibold">{title}</h1>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto p-4">
        <ul className="space-y-1">
          {/* Main menu items */}
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.view;
            return (
              <li key={item.view}>
                <button
                  onClick={() => handleMenuClick(item)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${isActive
                      ? 'bg-blue-50 text-blue-700'
                      : 'text-gray-700 hover:bg-gray-100'
                    }`}
                >
                  <Icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </button>
              </li>
            );
          })}

          {/* Dropdown groups */}
          {dropdownGroups.map((group) => {
            const GroupIcon = group.icon;
            const isOpen = openDropdowns[group.label] || false;

            return (
              <li key={group.label}>
                <button
                  onClick={() => toggleDropdown(group.label)}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors text-gray-700 hover:bg-gray-100"
                >
                  <GroupIcon className="w-5 h-5" />
                  <span className="flex-1 text-left">{group.label}</span>
                  {isOpen ? (
                    <ChevronUp className="w-4 h-4" />
                  ) : (
                    <ChevronDown className="w-4 h-4" />
                  )}
                </button>
                {isOpen && (
                  <ul className="mt-1 ml-4 space-y-1">
                    {group.items.map((item) => {
                      const Icon = item.icon;
                      const isActive = currentView === item.view;
                      return (
                        <li key={item.view}>
                          <button
                            onClick={() => handleMenuClick(item)}
                            className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg transition-colors ${isActive
                                ? 'bg-blue-50 text-blue-700'
                                : 'text-gray-700 hover:bg-gray-100'
                              }`}
                          >
                            <Icon className="w-4 h-4" />
                            <span>{item.label}</span>
                          </button>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </li>
            );
          })}
        </ul>
      </nav>

      {/* User section (optional) */}
      {user && (
        <div className="p-4 border-t border-gray-200">
          <div className="mb-3 px-4 py-2 rounded-lg bg-gray-100">
            <p className="text-gray-600 text-sm">{user.label || 'User Details'}</p>
            <div className="flex items-center gap-2 mt-1 mb-3">
              <User className="w-4 h-4 text-gray-500" />
              <span className="text-gray-700">{user.name}</span>
            </div>

            {/* Profile and Logout buttons */}
            <div className="flex gap-2">
              {onProfileClick && (
                <button
                  onClick={onProfileClick}
                  className={`flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-lg transition-colors ${currentView === 'profile'
                      ? 'bg-blue-50 text-blue-700'
                      : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-300'
                    }`}
                >
                  <User className="w-4 h-4" />
                  <span className="text-sm">Profile</span>
                </button>
              )}
              {onLogoutClick && (
                <button
                  onClick={onLogoutClick}
                  className="flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-lg transition-colors bg-red-50 text-red-700 hover:bg-red-100 border border-red-300"
                >
                  <LogOut className="w-4 h-4" />
                  <span className="text-sm">Logout</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </aside>
  );
}