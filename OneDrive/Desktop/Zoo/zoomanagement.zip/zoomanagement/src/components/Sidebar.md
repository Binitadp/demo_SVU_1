
## Installation

```bash
# Install required dependencies
npm install lucide-react
```

## Basic Usage

```tsx
import { Sidebar, type MenuItem, type DropdownGroup } from './components/Sidebar';
import { Home, Settings, Users } from 'lucide-react';

function App() {
  const [currentView, setCurrentView] = useState('home');

  const menuItems: MenuItem[] = [
    { icon: Home, label: 'Home', view: 'home' },
    { icon: Users, label: 'Users', view: 'users' },
  ];

  return (
    <Sidebar
      title="My App"
      menuItems={menuItems}
      currentView={currentView}
      onViewChange={setCurrentView}
    />
  );
}
```

## Advanced Usage with Dropdown Groups

```tsx
import { Sidebar, type MenuItem, type DropdownGroup } from './components/Sidebar';
import { 
  Home, 
  Users, 
  Settings, 
  HelpCircle, 
  Mail, 
  Phone 
} from 'lucide-react';

function App() {
  const [currentView, setCurrentView] = useState('home');

  const menuItems: MenuItem[] = [
    { icon: Home, label: 'Home', view: 'home' },
    { icon: Users, label: 'Users', view: 'users' },
  ];

  const dropdownGroups: DropdownGroup[] = [
    {
      icon: HelpCircle,
      label: 'Support',
      items: [
        { icon: Mail, label: 'Contact Us', view: 'contact' },
        { icon: Phone, label: 'Help Center', view: 'help' },
        { icon: Settings, label: 'Settings', view: 'settings' },
      ],
    },
  ];

  return (
    <Sidebar
      title="My App"
      menuItems={menuItems}
      dropdownGroups={dropdownGroups}
      currentView={currentView}
      onViewChange={setCurrentView}
      user={{
        name: 'Jane Smith',
        label: 'User Account'
      }}
      onProfileClick={() => setCurrentView('profile')}
      onLogoutClick={() => console.log('Logout clicked')}
    />
  );
}
```

## Props API

### `SidebarProps`

| Prop | Type | Required | Default | Description |
|------|------|----------|---------|-------------|
| `title` | `string` | No | `'App'` | Branding title displayed at the top of the sidebar |
| `menuItems` | `MenuItem[]` | Yes | - | Array of main menu items |
| `dropdownGroups` | `DropdownGroup[]` | No | `[]` | Array of dropdown groups |
| `currentView` | `string` | Yes | - | Currently active view |
| `onViewChange` | `(view: string) => void` | Yes | - | Callback when a menu item is clicked |
| `user` | `SidebarUser` | No | `undefined` | User details (omit to hide user section) |
| `onProfileClick` | `() => void` | No | `undefined` | Callback for profile button |
| `onLogoutClick` | `() => void` | No | `undefined` | Callback for logout button |

### `MenuItem`

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| `icon` | `React.ComponentType<React.SVGProps<SVGSVGElement>>` | Yes | Icon component (e.g., from Lucide React) |
| `label` | `string` | Yes | Display text for the menu item |
| `view` | `string` | Yes | View identifier |
| `onClick` | `() => void` | No | Custom click handler (overrides `onViewChange`) |

### `DropdownGroup`

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| `icon` | `React.ComponentType<React.SVGProps<SVGSVGElement>>` | Yes | Icon component for the group header |
| `label` | `string` | Yes | Display text for the dropdown group |
| `items` | `MenuItem[]` | Yes | Array of menu items in this group |

### `SidebarUser`

| Property | Type | Required | Default | Description |
|----------|------|----------|---------|-------------|
| `name` | `string` | Yes | - | User's name |
| `label` | `string` | No | `'User Details'` | Label above the user's name |

## Custom Click Handlers

You can provide custom `onClick` handlers for individual menu items to override the default `onViewChange` behavior:

```tsx
const menuItems: MenuItem[] = [
  { 
    icon: Home, 
    label: 'Home', 
    view: 'home' 
  },
  { 
    icon: ExternalLink, 
    label: 'External Link', 
    view: 'external',
    onClick: () => window.open('https://example.com', '_blank')
  },
];
```

## Multiple Dropdown Groups

You can create multiple dropdown sections:

```tsx
const dropdownGroups: DropdownGroup[] = [
  {
    icon: Settings,
    label: 'Admin',
    items: [
      { icon: Users, label: 'Manage Users', view: 'admin-users' },
      { icon: Shield, label: 'Permissions', view: 'admin-permissions' },
    ],
  },
  {
    icon: HelpCircle,
    label: 'Support',
    items: [
      { icon: Mail, label: 'Contact', view: 'contact' },
      { icon: Book, label: 'Docs', view: 'docs' },
    ],
  },
];
```

## Minimal Configuration (No User Section)

For a simple sidebar without user details:

```tsx
<Sidebar
  title="Simple App"
  menuItems={menuItems}
  currentView={currentView}
  onViewChange={setCurrentView}
/>
```

## Styling

The sidebar uses Tailwind CSS classes. To customize colors or spacing, modify the component's className strings in `Sidebar.tsx`.

## License

This component is part of the Zootopia project and can be freely used in other projects.
